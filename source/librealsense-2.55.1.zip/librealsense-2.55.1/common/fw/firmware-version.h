/* License: Apache 2.0. See LICENSE file in root directory.
   Copyright(c) 2017-24 Intel Corporation. All Rights Reserved. */

#pragma once

#define D4XX_RECOMMENDED_FIRMWARE_VERSION "5.16.0.1"

