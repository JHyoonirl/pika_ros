// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__MSG__IMU_INFO_HPP_
#define REALSENSE2_CAMERA_MSGS__MSG__IMU_INFO_HPP_

#include "realsense2_camera_msgs/msg/detail/imu_info__struct.hpp"
#include "realsense2_camera_msgs/msg/detail/imu_info__builder.hpp"
#include "realsense2_camera_msgs/msg/detail/imu_info__traits.hpp"
#include "realsense2_camera_msgs/msg/detail/imu_info__type_support.hpp"

#endif  // REALSENSE2_CAMERA_MSGS__MSG__IMU_INFO_HPP_
