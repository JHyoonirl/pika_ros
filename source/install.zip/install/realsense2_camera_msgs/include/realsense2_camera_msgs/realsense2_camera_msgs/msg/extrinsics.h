// generated from rosidl_generator_c/resource/idl.h.em
// with input from realsense2_camera_msgs:msg/Extrinsics.idl
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_H_
#define REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_H_

#include "realsense2_camera_msgs/msg/detail/extrinsics__struct.h"
#include "realsense2_camera_msgs/msg/detail/extrinsics__functions.h"
#include "realsense2_camera_msgs/msg/detail/extrinsics__type_support.h"

#endif  // REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_H_
