#include "cnmatrix/cn_matrix.h"
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

//#define SV_MATRIX_IS_COL_MAJOR 1
#define CN_HAS_SQROOT 1

#ifdef __cplusplus
}
#endif