// generated from rosidl_generator_c/resource/idl.h.em
// with input from data_msgs:srv/CaptureService.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__SRV__CAPTURE_SERVICE_H_
#define DATA_MSGS__SRV__CAPTURE_SERVICE_H_

#include "data_msgs/srv/detail/capture_service__struct.h"
#include "data_msgs/srv/detail/capture_service__functions.h"
#include "data_msgs/srv/detail/capture_service__type_support.h"

#endif  // DATA_MSGS__SRV__CAPTURE_SERVICE_H_
