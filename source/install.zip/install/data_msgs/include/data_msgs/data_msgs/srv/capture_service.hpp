// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__SRV__CAPTURE_SERVICE_HPP_
#define DATA_MSGS__SRV__CAPTURE_SERVICE_HPP_

#include "data_msgs/srv/detail/capture_service__struct.hpp"
#include "data_msgs/srv/detail/capture_service__builder.hpp"
#include "data_msgs/srv/detail/capture_service__traits.hpp"
#include "data_msgs/srv/detail/capture_service__type_support.hpp"

#endif  // DATA_MSGS__SRV__CAPTURE_SERVICE_HPP_
